﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //BulletedList1.Items.Add("PHP");
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            BulletedList2.Items.Clear();
            BulletedList2.Items.Add(Calendar1.SelectedDate.ToLongDateString());
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double alis, satis, kar;
            alis = Convert.ToDouble(TextBox1.Text);
            kar = Convert.ToDouble(TextBox2.Text);
            satis = alis + (alis * kar / 100);
            if(CheckBox1.Checked)
            {
                satis += satis * 0.18;
            }
            Label1.Text = satis.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                try
                {
                    if (FileUpload1.PostedFile.ContentType == "image/jpeg")
                    {
                        if (FileUpload1.PostedFile.ContentLength < 102000)
                        {
                            FileUpload1.SaveAs(Server.MapPath("~/im/") + FileUpload1.FileName);
                            Label2.Text = "Dosya Adı: " + FileUpload1.PostedFile.FileName +
                                "<br>Dosya Boyutu: " + FileUpload1.PostedFile.ContentLength +
                                "<br>Dosyanın Türü: " + FileUpload1.PostedFile.ContentType;

                        }
                        else
                            Label2.Text = "Maksimum 100KB olmalı.";
                    }
                    else
                        Label2.Text = "Resim Dosyası yükleyiniz";
                }
                catch (Exception ex)
                {
                    Label2.Text = "Hata oluştu " + ex.Message.ToString();
                }
            }
            else
                Label2.Text = "Resim Dosyası seçiniz.";
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Label3.Text = "ASP.NET ImageButton Click Olayı ";
            Label3.Text += "<br> Resmin tıklanan X Koordinatı: " + e.X.ToString();
            Label3.Text += "<br> Resmin tıklanan Y Koordinatı: " + e.Y.ToString();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Label3.Text = "Link Buttona tıklandı. ";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = (MultiView1.ActiveViewIndex + 1) % 2;
        }
    }
}